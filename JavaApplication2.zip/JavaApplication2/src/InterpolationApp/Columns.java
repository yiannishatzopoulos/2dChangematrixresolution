/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InterpolationApp;

import java.util.LinkedList;

/**
 *
 * @author yiannis
 */
public class Columns {

    public LinkedList<Point> rows = new LinkedList<>();
}
