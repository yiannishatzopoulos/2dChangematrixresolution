/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InterpolationApp;

/**
 *
 * @author yiannis
 */
public class Point {
    
    public Point() {}

    public double lat = 0.0;
    public double lng = 0.0;
    public double value = 0.0;

}
