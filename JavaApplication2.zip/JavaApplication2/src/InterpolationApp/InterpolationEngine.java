/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InterpolationApp;

/**
 *
 * @author yiannis
 */
import java.util.*;

public class InterpolationEngine {

    private Point[][] pPointsTable = null;
    private final LinkedList<Point> collectionofPoints = new LinkedList<>();

    private double mylat_start = 0.0;
    private double mylng_start = 0.0;
    private int mylat_count = 0;
    private int mylng_count = 0;

    //------------------------------------------------------------------------------
    public double[][] Execute(double input_start_lng,
            double input_start_lat,
            double orig_step,
            double new_step,
            double[][] input) {

        FillDataBuffer(input_start_lng,
                input_start_lat,
                orig_step,
                input);

        Matrix horzontalinterpolation = InterpolateHorizontally(new_step);

        // transitionary table, with interpolation per x axis complete
        double[][] hinterpolationtable = horzontalinterpolation.convert2TableFromRows();

        // now interpolate vertically
        FillDataBuffer(input_start_lng,
                input_start_lat,
                orig_step,
                hinterpolationtable);

        Matrix vinterpolationMatrix = InterpolateVertically(new_step);

        // convert into table
        return vinterpolationMatrix.convert2TableFromColumns();

    }

//------------------------------------------------------------------------------
    public void print(double[][] data) {
        System.out.println();

        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[0].length; j++) {

                System.out.print(data[i][j]);
                System.out.print(" , ");

            }
            System.out.println();
        }

    }

//---------------------------------------------------------------------
    public void FillDataBuffer(double lng_start,
            double lat_start,
            double initial_step,
            double[][] data
    ) {

        pPointsTable = null;

        mylat_start = lat_start;
        mylng_start = lng_start;
        mylat_count = data.length;
        mylng_count = data[0].length;

        pPointsTable = new Point[mylat_count][mylng_count];

        for (int i = 0; i < mylat_count; i++) {
            for (int j = 0; j < mylng_count; j++) {
                pPointsTable[i][j] = new Point();

                pPointsTable[i][j].value = data[i][j];
                pPointsTable[i][j].lat = lat_start - (i * initial_step * 1.00);
                pPointsTable[i][j].lng = lng_start + (j * initial_step * 1.00);
            }
        }

    }

    //------------------------------------------------------------------------
    private int FindhorizontalInterpolationSpot(Point[][] ppa,
            int lineno,
            double loc,
            int continuefrom) {
        int i = 0;
        int j = 0;
        int len = ppa[0].length;
        if (continuefrom > 0) {
            continuefrom--;
        }

        for (i = continuefrom; i < len - 1; i++) {
            if (ppa[lineno][i].lng <= loc && loc <= ppa[lineno][i + 1].lng) {
                j = i;
                break;
            }
        }

        return j;
    }

    //------------------------------------------------------------------------
    private int FindVerticalInterpolationSpot(Point[][] ppa,
            int columnno,
            double loc,
            int continuefrom) {
        int i = 0;
        int j = 0;
        int len = ppa.length;
        if (continuefrom > 0) {
            continuefrom--;
        }
        for (i = continuefrom; i < len - 1; i++) {
            if (ppa[i][columnno].lat >= loc && loc >= ppa[i + 1][columnno].lat) {
                j = i;
                break;
            }
        }

        return j;
    }

    //------------------------------------------------------------------------
    private double FindHorizontalPointRelation(Point[][] ppa,
            int row,
            int column,
            double loc) {

        double d = 0.0;

        double v1 = ppa[row][column].value;
        double lng1 = ppa[row][column].lng;

        double v2 = ppa[row][column + 1].value;
        double lng2 = ppa[row][column + 1].lng;

        double r = (loc - lng1) / (lng2 - lng1);

        d = v1 + ((v2 - v1) * r);

        return d;

    }

    //------------------------------------------------------------------------
    private double FindVerticalPointRelation(Point[][] ppa,
            int row,
            int column,
            double loc) {

        double d = 0.0;

        //if (row+1>= ppa.length) return d;
        double v1 = ppa[row][column].value;
        double lat1 = ppa[row][column].lat;

        double v2 = ppa[row + 1][column].value;
        double lat2 = ppa[row + 1][column].lat;

        double r = (lat1 - loc) / (lat1 - lat2);

        d = v1 + ((v2 - v1) * r);

        return d;

    }
    //------------------------------------------------------------------------

    private Matrix InterpolateHorizontally(double newstep) {

        Matrix nn = new Matrix();

        for (int i = 0; i < mylat_count; i++) {

            LinkedList<Point> p3 = InterpolatelineHoriz(pPointsTable, newstep, i);
            Rows rr = new Rows();
            for (int j = 0; j < p3.size(); j++) {
                rr.column.add(p3.get(j));
            }
            nn.Rows.add(rr);

        }
        return nn;
    }
    //------------------------------------------------------------------------

    private Matrix InterpolateVertically(double newstep) {

        Matrix nn = new Matrix();

        for (int i = 0; i < mylng_count; i++) {

            LinkedList<Point> p3 = InterpolatelineVert(pPointsTable, newstep, i);
            Columns cc = new Columns();
            for (int j = 0; j < p3.size(); j++) {
                cc.rows.add(p3.get(j));
            }
            nn.Columns.add(cc);

        }
        return nn;
    }

    //------------------------------------------------------------------------
    /**
     *
     * @param step
     */
    private LinkedList<Point> InterpolatelineHoriz(Point[][] ppa,
            double newstep,
            int row) {

        collectionofPoints.clear();
        collectionofPoints.add(ppa[row][0]);

        double lat = ppa[row][0].lat;

        int cols = ppa[row].length;

        double step = ppa[row][0].lng + newstep;
        double end = ppa[row][cols - 1].lng;
        // track margin

        int n = 0;
        while (step <= end) {
            n = FindhorizontalInterpolationSpot(ppa, row, step, n);
            double d = FindHorizontalPointRelation(ppa, row, n, step);

            Point p = new Point();
            p.lat = lat;
            p.lng = step;
            p.value = d;
            collectionofPoints.add(p);
            step = step + newstep;

        }

        // spill off
        if (step>end) {
      
            double d = ppa[row][cols - 1].value; 
            Point p = new Point();
            p.lat = lat;
            p.lng = step;
            p.value = d;
            collectionofPoints.add(p);
        }
        
        return collectionofPoints;
    }

    //------------------------------------------------------------------------
    /**
     *
     * @param step
     */
    private LinkedList<Point> InterpolatelineVert(Point[][] ppa,
            double newstep,
            int columnno) {

        collectionofPoints.clear();
        collectionofPoints.add(ppa[0][columnno]);

        double lng = ppa[0][columnno].lng;

        int len = ppa.length;

        double step = ppa[0][columnno].lat - newstep;
        double end = ppa[len - 1][columnno].lat;
        // track margin

        int row = 0;

        while (step >= end) {

            row = FindVerticalInterpolationSpot(ppa, columnno, step, row);
            double d = FindVerticalPointRelation(ppa, row, columnno, step);

            Point p = new Point();
            p.lat = step;
            p.lng = lng;
            p.value = d;
            collectionofPoints.add(p);
            step = step - newstep;

        }
        
        // spill off
        if (step < end) {
            double d = ppa[len - 1][columnno].value;
            Point p = new Point();
            p.lat = step;
            p.lng = lng;
            p.value = d;
            collectionofPoints.add(p);
        }

        return collectionofPoints;
    }

}
