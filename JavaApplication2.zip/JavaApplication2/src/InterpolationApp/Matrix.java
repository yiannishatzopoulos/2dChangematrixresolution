/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InterpolationApp;

import java.util.LinkedList;

/**
 *
 * @author yiannis
 */
public class Matrix {

    public LinkedList<Rows> Rows = new LinkedList<>();

    public LinkedList<Columns> Columns = new LinkedList<>();

    //------------------------------------------------------------
    
    public double[][] convert2TableFromRows() {
        int rows = Rows.size();
        int columns = Rows.get(0).column.size();

        double[][] dd = new double[rows][columns];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {

                dd[i][j] = Rows.get(i).column.get(j).value;
            }
        }

        Rows.clear();
        
        return dd;

    }

    //------------------------------------------------------------
    
    public double[][] convert2TableFromColumns() {
        int rows = Columns.get(0).rows.size();
        int columns = Columns.size();

        double[][] dd = new double[rows][columns];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {

                dd[i][j] = Columns.get(j).rows.get(i).value;
            }
        }

        Columns.clear();
        return dd;
    }

}
